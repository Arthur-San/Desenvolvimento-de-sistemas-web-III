//Imprima todos os números de 150 a 300.
package trabalhoavaliativo2;
public class ImprimaTodosN300 {
    public static void main(String[] args) {
        int numero = 301;
        
       for(int i = 150; i < numero; ++i){
           System.out.println("Os numero de 150 ate 300 é: " + i );
       }
    }
}
