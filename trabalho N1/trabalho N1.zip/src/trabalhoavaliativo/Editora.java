package trabalhoavaliativo;
public class Editora {
  public int codEditora;
  public String razaoSocial, email, telefone;
}
