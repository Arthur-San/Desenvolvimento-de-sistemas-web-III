package trabalhoavaliativo;
public class Livros {
    public int codigo;
    public String descLivro, ISBN;
}
